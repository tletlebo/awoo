<?php
	exec("pgrep svxlink", $pids);
	if(empty($pids)) 
	{
		echo "SVXLINK is not Running";
	}
	else
	{
		echo "SVXLINK is PID: ".$pids;
	}
?>
<html>

<form>
<input type="submit" name="start" value="start" />
<br />
<input type="submit" name="kill" value="kill" />
</form>
	
</html>
<?php
	if( isset( $_REQUEST['start'] ))
	{
		exec("svxlink --daemon", $return);
	}

	if( isset( $_REQUEST['kill'] ))
	{
		exec("pkill svxlink", $return);
	}
	echo $return;
?>