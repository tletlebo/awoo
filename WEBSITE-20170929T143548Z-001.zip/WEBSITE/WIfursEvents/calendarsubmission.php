<?php
$botToken = "280907942:AAFTfiPE5alUNTOE3iPrGh2c3dFaZlQzvlg";
$website = "https://api.telegram.org/bot".$botToken;

//$update2 = file_get_contents('php://input');
$name = $_POST["name"];
$contact = $_POST["contact"];
$event= $_POST["event"];
$location = $_POST["location"];
$date = $_POST["date"];
$starttime = $_POST["starttime"];
$endtime = $_POST["endtime"];
$fursuit = $_POST["fursuit"];
$facebook = $_POST["facebook"];
$description = $_POST["description"];

$send = "Calendar #Submisssion \nName: ".$name."\nContact: ".$contact."\nEvent: ".$event."\nLocation: ".$location."\nDate(s): ".$date."\nStart Time: ".$starttime."\nEnd Time: ".$endtime."\nFursuit: ".$fursuit."\nFacebook: ".$facebook."\nDescription: ".$description;

sendMessage(156651178, $send);
//sendMessage(156651178, $send);
print( "Your Message has been sent!");

function sendMessage ($chatId, $message) {
       
        $url = $GLOBALS[website]."/sendMessage?chat_id=".$chatId."&text=".urlencode($message);
        file_get_contents($url);
       
}

?>
  